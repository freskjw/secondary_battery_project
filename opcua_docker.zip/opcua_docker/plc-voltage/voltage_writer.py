# v6 ★ PATCHED: P03 공정로그 복원(OK/NG 기록)
import asyncio, os, sys, time, struct
from dotenv import load_dotenv
from pymcprotocol import Type3E
from asyncua import Client, ua
from lot_db_helper import get_next_lot, update_module, get_conn_cursor

load_dotenv("config.env")

PLC_IP     = os.getenv("PLC_IP", "192.168.3.30")
PLC_PORT   = int(os.getenv("PLC_PORT", "6003"))
PLC_DEV    = os.getenv("PLC_DEVICE", "D100")  # 32-bit float (2 word)
POLL       = 0.05

UA_EP      = os.getenv("UA_ENDPOINT", "opc.tcp://opcua-server:4840/inspect/server/")
NS_URI     = os.getenv("UA_NAMESPACE", "http://inspect.system")

LOW        = float(os.getenv("VOLT_LOW_LIMIT",  "7.7"))
HIGH       = float(os.getenv("VOLT_HIGH_LIMIT", "8.3"))

plc = Type3E()
plc.host, plc.port, plc.unit_code, plc.timeout = PLC_IP, PLC_PORT, 0xFF, 3

async def plc_connect():
    retry = 0
    while True:
        try:
            await asyncio.to_thread(plc.connect, PLC_IP, PLC_PORT)
            print(f" PLC connected ({PLC_IP}:{PLC_PORT})")
            return
        except Exception as e:
            retry += 1
            print(f" PLC connect failed, retry {retry}: {e}")
            await asyncio.sleep(1)

async def read_float():
    w = await asyncio.to_thread(plc.batchread_wordunits, PLC_DEV, 2)
    raw = (w[1] << 16) | (w[0] & 0xFFFF)
    return struct.unpack('<f', raw.to_bytes(4, 'little'))[0]

async def read_done_bit():
    return bool((await asyncio.to_thread(plc.batchread_bitunits, "M572", 1))[0])

async def main():
    await plc_connect()
    async with Client(UA_EP) as cli:
        idx       = await cli.get_namespace_index(NS_URI)
        insp      = await cli.nodes.objects.get_child([f"{idx}:InspectSystem"])
        volt_node = await insp.get_child([f"{idx}:Voltage"])
        res_node  = await insp.get_child([f"{idx}:VoltageResult"])
        flag_node = await insp.get_child([f"{idx}:TriggerFlag"])

        prev = False
        while True:
            trig = await read_done_bit()
            if not prev and trig:
                volt   = await read_float()
                status = "OK" if LOW <= volt <= HIGH else "NG"

                lot = get_next_lot(stage=3)   # scrap 제외
                if lot is None:
                    print("[Volt] ℹ️ pending LOT not found (maybe scrapped at P02) — skip")
                else:
                    update_module(
                        lot,
                        voltage=volt,
                        voltage_ok=1 if status == "OK" else 0,
                        stage3_done=1,
                    )
                    # P03 공정 로그 기록 (cp-calculator 용)
                    with get_conn_cursor() as (_, cur):
                        cur.execute("""
                            INSERT INTO module_process_log
                              (lot_no, module_type, process_id, measure_value, result, created_at)
                            VALUES (%s, %s, 'P03', %s, %s, NOW())
                        """, (lot, '2x3' if '6P' in lot else '2x4', volt, status))

                await volt_node.write_value(ua.Variant(volt, ua.VariantType.Float))
                await res_node.write_value(ua.Variant(status, ua.VariantType.String))
                await flag_node.write_value(ua.Variant(True, ua.VariantType.Boolean))

                print(f"[Volt] {time.strftime('%H:%M:%S')}  {lot or '--'}  {volt:6.3f} V → {status}")

            prev = trig
            await asyncio.sleep(POLL)

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        sys.exit(0)