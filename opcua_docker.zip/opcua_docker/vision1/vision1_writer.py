# vision1_writer.py  (v5.1)
import asyncio, os, time
from dotenv import load_dotenv
from pymcprotocol import Type3E
from asyncua import Client, ua
from lot_db_helper import create_module_lot, update_module

load_dotenv("config.env")
PLC_IP   = os.getenv("PLC_IP", "192.168.3.30")
PLC_PORT = int(os.getenv("PLC_PORT", "6007"))
UA_EP    = os.getenv("UA_ENDPOINT", "opc.tcp://opcua-server:4840/inspect/server/")
NS_URI   = os.getenv("UA_NAMESPACE", "http://inspect.system")
POLL     = 0.05

plc = Type3E()
plc.host, plc.port, plc.unit_code, plc.timeout = PLC_IP, PLC_PORT, 0xFF, 3

async def plc_connect():
    retry = 0
    while True:
        try:
            await asyncio.to_thread(plc.connect, PLC_IP, PLC_PORT)
            print(f" PLC connected ({PLC_IP}:{PLC_PORT})")
            return
        except Exception as e:
            retry += 1
            print(f" PLC connect failed, retry {retry}: {e}")
            await asyncio.sleep(1)

async def read_bits():
    raw = await asyncio.to_thread(plc.batchread_bitunits, "M240", 22)  # M240~M261
    return {f"M{240+i}": bool(raw[i]) for i in range(22)}

async def main():
    await plc_connect()
    async with Client(UA_EP) as cli:
        idx = await cli.get_namespace_index(NS_URI)
        insp = await cli.nodes.objects.get_child([f"{idx}:InspectSystem"])
        lot_node  = await insp.get_child([f"{idx}:LotNo"])
        ang_node  = await insp.get_child([f"{idx}:Angle"])
        v1_node   = await insp.get_child([f"{idx}:Vision1Result"])
        flag_node = await insp.get_child([f"{idx}:TriggerFlag"])

        prev_cap = False
        while True:
            b = await read_bits()
            cap = b["M261"]  # 촬영 완료

            if not prev_cap and cap:
                p_type   = "6P" if b["M240"] else "8P"
                angle_ok = b["M242"]
                angle    = 0.0 if angle_ok else 90.0
                result   = "OK" if angle_ok else "NG"

                lot = create_module_lot(p_type)

                await lot_node.write_value(ua.Variant(lot, ua.VariantType.String))
                await ang_node.write_value(ua.Variant(angle, ua.VariantType.Float))
                await v1_node.write_value(ua.Variant(result, ua.VariantType.String))
                await flag_node.write_value(ua.Variant(True, ua.VariantType.Boolean))

                update_module(
                    lot,
                    v1_angle=angle,
                    v1_ok=1 if result == "OK" else 0,
                    stage1_done=1,
                )

                print(f"[V1] {time.strftime('%H:%M:%S')}  {lot}  angle={angle:.0f}° → {result}")

            prev_cap = cap
            await asyncio.sleep(POLL)

if __name__ == "__main__":
    asyncio.run(main())