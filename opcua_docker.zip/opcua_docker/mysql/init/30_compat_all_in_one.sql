-- 30_compat_all_in_one.sql (SAFE / DUMMY-ONLY)
-- 목적: secondary_battery_dummy_db의 스키마를 리포터/시더가 기대하는 형태로 정렬
-- 주의: 본 DB(secondary_battery_db)의 VIEW(process_capability) 등은 건드리지 않음

SET NAMES utf8mb4;
SET sql_mode = 'STRICT_ALL_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION';

-- -------------------------------------------------------------------
-- 더미 DB 보장
-- -------------------------------------------------------------------
CREATE DATABASE IF NOT EXISTS secondary_battery_dummy_db
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_general_ci;

-- ===================================================================
-- module: 타임스탬프/결과 컬럼 보강 (테이블이 있을 때만 실행)
-- ===================================================================
SET @has_module := (
  SELECT COUNT(*) FROM information_schema.tables
  WHERE table_schema='secondary_battery_dummy_db' AND table_name='module'
);

-- v1_time
SET @need := IF(@has_module>0,
  (SELECT COUNT(*)=0 FROM information_schema.columns
   WHERE table_schema='secondary_battery_dummy_db' AND table_name='module' AND column_name='v1_time'),
  0);
SET @sql := IF(@need=1,
  'ALTER TABLE secondary_battery_dummy_db.module ADD COLUMN v1_time TIMESTAMP NULL',
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- v2_time
SET @need := IF(@has_module>0,
  (SELECT COUNT(*)=0 FROM information_schema.columns
   WHERE table_schema='secondary_battery_dummy_db' AND table_name='module' AND column_name='v2_time'),
  0);
SET @sql := IF(@need=1,
  'ALTER TABLE secondary_battery_dummy_db.module ADD COLUMN v2_time TIMESTAMP NULL',
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- voltage_time
SET @need := IF(@has_module>0,
  (SELECT COUNT(*)=0 FROM information_schema.columns
   WHERE table_schema='secondary_battery_dummy_db' AND table_name='module' AND column_name='voltage_time'),
  0);
SET @sql := IF(@need=1,
  'ALTER TABLE secondary_battery_dummy_db.module ADD COLUMN voltage_time TIMESTAMP NULL',
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- vision1_result
SET @need := IF(@has_module>0,
  (SELECT COUNT(*)=0 FROM information_schema.columns
   WHERE table_schema='secondary_battery_dummy_db' AND table_name='module' AND column_name='vision1_result'),
  0);
SET @sql := IF(@need=1,
  'ALTER TABLE secondary_battery_dummy_db.module ADD COLUMN vision1_result VARCHAR(10) NULL',
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- vision2_result
SET @need := IF(@has_module>0,
  (SELECT COUNT(*)=0 FROM information_schema.columns
   WHERE table_schema='secondary_battery_dummy_db' AND table_name='module' AND column_name='vision2_result'),
  0);
SET @sql := IF(@need=1,
  'ALTER TABLE secondary_battery_dummy_db.module ADD COLUMN vision2_result VARCHAR(10) NULL',
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- voltage_result
SET @need := IF(@has_module>0,
  (SELECT COUNT(*)=0 FROM information_schema.columns
   WHERE table_schema='secondary_battery_dummy_db' AND table_name='module' AND column_name='voltage_result'),
  0);
SET @sql := IF(@need=1,
  'ALTER TABLE secondary_battery_dummy_db.module ADD COLUMN voltage_result VARCHAR(10) NULL',
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- ===================================================================
-- kpi_target: 없으면 생성 + 컬럼 보강
-- ===================================================================
CREATE TABLE IF NOT EXISTS secondary_battery_dummy_db.kpi_target (
  kpi_code       VARCHAR(64) PRIMARY KEY,
  target         DECIMAL(10,3) NULL,
  warn_threshold DECIMAL(10,3) NULL,
  crit_threshold DECIMAL(10,3) NULL,
  updated_at     TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- target
SET @exists := (
  SELECT COUNT(*) FROM information_schema.columns
  WHERE table_schema='secondary_battery_dummy_db' AND table_name='kpi_target' AND column_name='target'
);
SET @sql := IF(@exists=0,
  'ALTER TABLE secondary_battery_dummy_db.kpi_target ADD COLUMN target DECIMAL(10,3) NULL',
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- warn_threshold
SET @exists := (
  SELECT COUNT(*) FROM information_schema.columns
  WHERE table_schema='secondary_battery_dummy_db' AND table_name='kpi_target' AND column_name='warn_threshold'
);
SET @sql := IF(@exists=0,
  'ALTER TABLE secondary_battery_dummy_db.kpi_target ADD COLUMN warn_threshold DECIMAL(10,3) NULL',
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- crit_threshold
SET @exists := (
  SELECT COUNT(*) FROM information_schema.columns
  WHERE table_schema='secondary_battery_dummy_db' AND table_name='kpi_target' AND column_name='crit_threshold'
);
SET @sql := IF(@exists=0,
  'ALTER TABLE secondary_battery_dummy_db.kpi_target ADD COLUMN crit_threshold DECIMAL(10,3) NULL',
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- updated_at
SET @exists := (
  SELECT COUNT(*) FROM information_schema.columns
  WHERE table_schema='secondary_battery_dummy_db' AND table_name='kpi_target' AND column_name='updated_at'
);
SET @sql := IF(@exists=0,
  'ALTER TABLE secondary_battery_dummy_db.kpi_target ADD COLUMN updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP',
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- ===================================================================
-- report_archive: 없으면 생성 + json_payload/audience/lang 보강
-- ===================================================================
CREATE TABLE IF NOT EXISTS secondary_battery_dummy_db.report_archive (
  id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  period        ENUM('D','W','M') NOT NULL,
  range_start   DATETIME NOT NULL,
  range_end     DATETIME NOT NULL,
  html_content  MEDIUMTEXT NULL,
  json_payload  JSON NULL,
  audience      ENUM('ALL','ENG','MGR') NOT NULL DEFAULT 'ALL',
  lang          VARCHAR(5) NOT NULL DEFAULT 'ko',
  created_at    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_period_rs_re (period, range_start, range_end)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- json_payload
SET @exists := (
  SELECT COUNT(*) FROM information_schema.columns
  WHERE table_schema='secondary_battery_dummy_db' AND table_name='report_archive' AND column_name='json_payload'
);
SET @sql := IF(@exists=0,
  'ALTER TABLE secondary_battery_dummy_db.report_archive ADD COLUMN json_payload JSON NULL',
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- audience
SET @exists := (
  SELECT COUNT(*) FROM information_schema.columns
  WHERE table_schema='secondary_battery_dummy_db' AND table_name='report_archive' AND column_name='audience'
);
SET @sql := IF(@exists=0,
  'ALTER TABLE secondary_battery_dummy_db.report_archive ADD COLUMN audience ENUM(''ALL'',''ENG'',''MGR'') NOT NULL DEFAULT ''ALL''',
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- lang
SET @exists := (
  SELECT COUNT(*) FROM information_schema.columns
  WHERE table_schema='secondary_battery_dummy_db' AND table_name='report_archive' AND column_name='lang'
);
SET @sql := IF(@exists=0,
  'ALTER TABLE secondary_battery_dummy_db.report_archive ADD COLUMN lang VARCHAR(5) NOT NULL DEFAULT ''ko''',
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- ===================================================================
-- pack: created_at 보강(옵션)
-- ===================================================================
SET @has_pack := (
  SELECT COUNT(*) FROM information_schema.tables
  WHERE table_schema='secondary_battery_dummy_db' AND table_name='pack'
);
SET @exists := IF(@has_pack>0,
  (SELECT COUNT(*) FROM information_schema.columns
   WHERE table_schema='secondary_battery_dummy_db' AND table_name='pack' AND column_name='created_at'),
  1);
SET @sql := IF(@has_pack>0 AND @exists=0,
  'ALTER TABLE secondary_battery_dummy_db.pack ADD COLUMN created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP',
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- ===================================================================
-- process_capability (dummy): 없으면 생성 + 컬럼/인덱스 보강 + 2x3/2x4 병합
-- ===================================================================
SET @has_pc := (
  SELECT COUNT(*) FROM information_schema.tables
  WHERE table_schema='secondary_battery_dummy_db' AND table_name='process_capability'
);
SET @sql := IF(@has_pc=0,
  "CREATE TABLE secondary_battery_dummy_db.process_capability (
     id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
     module_type  VARCHAR(10) NOT NULL,
     window_start DATETIME NOT NULL,
     window_end   DATETIME NOT NULL,
     cp           DECIMAL(10,4) NULL,
     cpk          DECIMAL(10,4) NULL,
     lsl          DECIMAL(10,3) NULL,
     usl          DECIMAL(10,3) NULL,
     mean         DECIMAL(10,3) NULL,
     sigma        DECIMAL(10,3) NULL,
     computed_at  TIMESTAMP NULL,
     PRIMARY KEY (id),
     UNIQUE KEY uniq_pc (module_type, window_start, window_end),
     KEY idx_time (window_start, window_end)
   ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4",
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- 각 컬럼 존재 시 체크 후 개별 추가
-- module_type
SET @exists := (
  SELECT COUNT(*) FROM information_schema.columns
  WHERE table_schema='secondary_battery_dummy_db' AND table_name='process_capability' AND column_name='module_type'
);
SET @sql := IF(@exists=0,
  'ALTER TABLE secondary_battery_dummy_db.process_capability ADD COLUMN module_type VARCHAR(10) NOT NULL',
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
-- window_start
SET @exists := (
  SELECT COUNT(*) FROM information_schema.columns
  WHERE table_schema='secondary_battery_dummy_db' AND table_name='process_capability' AND column_name='window_start'
);
SET @sql := IF(@exists=0,
  'ALTER TABLE secondary_battery_dummy_db.process_capability ADD COLUMN window_start DATETIME NOT NULL',
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
-- window_end
SET @exists := (
  SELECT COUNT(*) FROM information_schema.columns
  WHERE table_schema='secondary_battery_dummy_db' AND table_name='process_capability' AND column_name='window_end'
);
SET @sql := IF(@exists=0,
  'ALTER TABLE secondary_battery_dummy_db.process_capability ADD COLUMN window_end DATETIME NOT NULL',
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
-- cp
SET @exists := (
  SELECT COUNT(*) FROM information_schema.columns
  WHERE table_schema='secondary_battery_dummy_db' AND table_name='process_capability' AND column_name='cp'
);
SET @sql := IF(@exists=0,
  'ALTER TABLE secondary_battery_dummy_db.process_capability ADD COLUMN cp DECIMAL(10,4) NULL',
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
-- cpk
SET @exists := (
  SELECT COUNT(*) FROM information_schema.columns
  WHERE table_schema='secondary_battery_dummy_db' AND table_name='process_capability' AND column_name='cpk'
);
SET @sql := IF(@exists=0,
  'ALTER TABLE secondary_battery_dummy_db.process_capability ADD COLUMN cpk DECIMAL(10,4) NULL',
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
-- lsl
SET @exists := (
  SELECT COUNT(*) FROM information_schema.columns
  WHERE table_schema='secondary_battery_dummy_db' AND table_name='process_capability' AND column_name='lsl'
);
SET @sql := IF(@exists=0,
  'ALTER TABLE secondary_battery_dummy_db.process_capability ADD COLUMN lsl DECIMAL(10,3) NULL',
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
-- usl
SET @exists := (
  SELECT COUNT(*) FROM information_schema.columns
  WHERE table_schema='secondary_battery_dummy_db' AND table_name='process_capability' AND column_name='usl'
);
SET @sql := IF(@exists=0,
  'ALTER TABLE secondary_battery_dummy_db.process_capability ADD COLUMN usl DECIMAL(10,3) NULL',
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
-- mean
SET @exists := (
  SELECT COUNT(*) FROM information_schema.columns
  WHERE table_schema='secondary_battery_dummy_db' AND table_name='process_capability' AND column_name='mean'
);
SET @sql := IF(@exists=0,
  'ALTER TABLE secondary_battery_dummy_db.process_capability ADD COLUMN mean DECIMAL(10,3) NULL',
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
-- sigma
SET @exists := (
  SELECT COUNT(*) FROM information_schema.columns
  WHERE table_schema='secondary_battery_dummy_db' AND table_name='process_capability' AND column_name='sigma'
);
SET @sql := IF(@exists=0,
  'ALTER TABLE secondary_battery_dummy_db.process_capability ADD COLUMN sigma DECIMAL(10,3) NULL',
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
-- computed_at
SET @exists := (
  SELECT COUNT(*) FROM information_schema.columns
  WHERE table_schema='secondary_battery_dummy_db' AND table_name='process_capability' AND column_name='computed_at'
);
SET @sql := IF(@exists=0,
  'ALTER TABLE secondary_battery_dummy_db.process_capability ADD COLUMN computed_at TIMESTAMP NULL',
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- 유니크 키 보강(uniq_pc 없으면 추가)
SET @has_uniq := (
  SELECT COUNT(*) FROM information_schema.statistics
  WHERE table_schema='secondary_battery_dummy_db'
    AND table_name='process_capability'
    AND index_name='uniq_pc'
);
SET @sql := IF(@has_uniq=0,
  "ALTER TABLE secondary_battery_dummy_db.process_capability
     ADD UNIQUE KEY uniq_pc (module_type, window_start, window_end)",
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- 2x3 → 병합
SET @has_23 := (
  SELECT COUNT(*) FROM information_schema.tables
  WHERE table_schema='secondary_battery_dummy_db' AND table_name='process_capability_2x3'
);
SET @sql := IF(@has_23>0,
  "INSERT INTO secondary_battery_dummy_db.process_capability AS new
     (module_type, window_start, window_end, cp, cpk, lsl, usl, mean, sigma, computed_at)
   SELECT '2x3', window_start, window_end, cp, cpk, lsl, usl, mean, sigma, computed_at
     FROM secondary_battery_dummy_db.process_capability_2x3
   ON DUPLICATE KEY UPDATE
     cp=new.cp, cpk=new.cpk,
     lsl=new.lsl, usl=new.usl,
     mean=new.mean, sigma=new.sigma,
     computed_at=new.computed_at",
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- 2x4 → 병합
SET @has_24 := (
  SELECT COUNT(*) FROM information_schema.tables
  WHERE table_schema='secondary_battery_dummy_db' AND table_name='process_capability_2x4'
);
SET @sql := IF(@has_24>0,
  "INSERT INTO secondary_battery_dummy_db.process_capability AS new
     (module_type, window_start, window_end, cp, cpk, lsl, usl, mean, sigma, computed_at)
   SELECT '2x4', window_start, window_end, cp, cpk, lsl, usl, mean, sigma, computed_at
     FROM secondary_battery_dummy_db.process_capability_2x4
   ON DUPLICATE KEY UPDATE
     cp=new.cp, cpk=new.cpk,
     lsl=new.lsl, usl=new.usl,
     mean=new.mean, sigma=new.sigma,
     computed_at=new.computed_at",
  'SELECT 1'); PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- ===================================================================
-- defect_code: 시더가 필요로 하므로 없으면 최소 스키마 생성
-- ===================================================================
CREATE TABLE IF NOT EXISTS secondary_battery_dummy_db.defect_code (
  code    VARCHAR(32) PRIMARY KEY,
  name_ko VARCHAR(100) NULL,
  name_en VARCHAR(100) NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SELECT 1;