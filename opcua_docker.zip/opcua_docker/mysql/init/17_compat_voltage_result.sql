/* 17_compat_voltage_result.sql
   - reporter 호환을 위해 module.voltage_result 생성 컬럼 추가
   - 우선순위: voltage_ok → 없으면 voltage(7.7~8.3) 범위 판정
*/

-- ===== 1) 더미 DB 패치 =====
USE secondary_battery_dummy_db;

-- 표현식 구성: voltage_ok 있으면 그걸 우선 사용
SET @has_ok := (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='module' AND COLUMN_NAME='voltage_ok'
);

SET @expr := IF(@has_ok=1,
  "CASE WHEN voltage_ok=1 THEN 'OK' WHEN voltage_ok=0 THEN 'NG' ELSE NULL END",
  "CASE WHEN voltage IS NULL THEN NULL WHEN voltage BETWEEN 7.7 AND 8.3 THEN 'OK' ELSE 'NG' END"
);

-- 컬럼 없으면 생성 (VIRTUAL generated column)
SET @col_exists := (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='module' AND COLUMN_NAME='voltage_result'
);

SET @sql := IF(@col_exists=0,
  CONCAT("ALTER TABLE `module` ADD COLUMN `voltage_result` VARCHAR(2) GENERATED ALWAYS AS (", @expr, ") VIRTUAL"),
  "SET @noop:=1"
);
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;


-- ===== 2) 메인 DB 패치 (향후 전환 대비) =====
USE `secondary_battery_db`;

SET @has_ok := (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='module' AND COLUMN_NAME='voltage_ok'
);

SET @expr := IF(@has_ok=1,
  "CASE WHEN voltage_ok=1 THEN 'OK' WHEN voltage_ok=0 THEN 'NG' ELSE NULL END",
  "CASE WHEN voltage IS NULL THEN NULL WHEN voltage BETWEEN 7.7 AND 8.3 THEN 'OK' ELSE 'NG' END"
);

SET @col_exists := (
  SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
  WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='module' AND COLUMN_NAME='voltage_result'
);

SET @sql := IF(@col_exists=0,
  CONCAT("ALTER TABLE `module` ADD COLUMN `voltage_result` VARCHAR(2) GENERATED ALWAYS AS (", @expr, ") VIRTUAL"),
  "SET @noop:=1"
);
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;