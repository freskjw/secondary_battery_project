/* 20_dummy_schema.sql — dummy DB 생성 + 안전 복제(테이블만) + 기준데이터 조건부 복사 */
/* VIEW(process_capability 등) 복제는 의존성 문제로 건너뜀 */

-- 공통 스키마 변수
SET @src_schema='secondary_battery_db';
SET @dst_schema='secondary_battery_dummy_db';

-- 1) 더미 DB 생성
CREATE DATABASE IF NOT EXISTS secondary_battery_dummy_db;

-- 2) 베이스 테이블만 LIKE 복제 (존재할 때만)
-- helper macro pattern: @t 설정 → @exists → @sql('CREATE ...' or 'SET @noop:=1') → PREPARE/EXECUTE

-- module
SET @t='module';
SET @exists=(SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES
             WHERE TABLE_SCHEMA=@src_schema AND TABLE_NAME=@t AND TABLE_TYPE='BASE TABLE');
SET @sql=IF(@exists=1,
  CONCAT('CREATE TABLE IF NOT EXISTS `',@dst_schema,'`.`',@t,'` LIKE `',@src_schema,'`.`',@t,'`'),
  'SET @noop:=1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- pack
SET @t='pack';
SET @exists=(SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES
             WHERE TABLE_SCHEMA=@src_schema AND TABLE_NAME=@t AND TABLE_TYPE='BASE TABLE');
SET @sql=IF(@exists=1,
  CONCAT('CREATE TABLE IF NOT EXISTS `',@dst_schema,'`.`',@t,'` LIKE `',@src_schema,'`.`',@t,'`'),
  'SET @noop:=1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- pack_module_map
SET @t='pack_module_map';
SET @exists=(SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES
             WHERE TABLE_SCHEMA=@src_schema AND TABLE_NAME=@t AND TABLE_TYPE='BASE TABLE');
SET @sql=IF(@exists=1,
  CONCAT('CREATE TABLE IF NOT EXISTS `',@dst_schema,'`.`',@t,'` LIKE `',@src_schema,'`.`',@t,'`'),
  'SET @noop:=1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- spec_limit
SET @t='spec_limit';
SET @exists=(SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES
             WHERE TABLE_SCHEMA=@src_schema AND TABLE_NAME=@t AND TABLE_TYPE='BASE TABLE');
SET @sql=IF(@exists=1,
  CONCAT('CREATE TABLE IF NOT EXISTS `',@dst_schema,'`.`',@t,'` LIKE `',@src_schema,'`.`',@t,'`'),
  'SET @noop:=1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- defect_code
SET @t='defect_code';
SET @exists=(SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES
             WHERE TABLE_SCHEMA=@src_schema AND TABLE_NAME=@t AND TABLE_TYPE='BASE TABLE');
SET @sql=IF(@exists=1,
  CONCAT('CREATE TABLE IF NOT EXISTS `',@dst_schema,'`.`',@t,'` LIKE `',@src_schema,'`.`',@t,'`'),
  'SET @noop:=1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- module_defect
SET @t='module_defect';
SET @exists=(SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES
             WHERE TABLE_SCHEMA=@src_schema AND TABLE_NAME=@t AND TABLE_TYPE='BASE TABLE');
SET @sql=IF(@exists=1,
  CONCAT('CREATE TABLE IF NOT EXISTS `',@dst_schema,'`.`',@t,'` LIKE `',@src_schema,'`.`',@t,'`'),
  'SET @noop:=1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- (중요) process_capability: VIEW 의존성 많으므로 더미 DB에선 복제하지 않음
-- 필요시 나중에 별도 스크립트로 생성

-- 3) kpi_target: 원본에 있으면 LIKE, 없으면 더미용 최소 스키마 생성
SET @exists_kpi=(SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES
                 WHERE TABLE_SCHEMA=@src_schema AND TABLE_NAME='kpi_target' AND TABLE_TYPE='BASE TABLE');
SET @sql=IF(@exists_kpi=1,
  CONCAT('CREATE TABLE IF NOT EXISTS `',@dst_schema,'`.kpi_target LIKE `',@src_schema,'`.kpi_target'),
  CONCAT('CREATE TABLE IF NOT EXISTS `',@dst_schema,"`.kpi_target (",
         " id INT AUTO_INCREMENT PRIMARY KEY,",
         " metric VARCHAR(64) NOT NULL,",
         " target_value DECIMAL(12,4) NULL,",
         " warning_low DECIMAL(12,4) NULL,",
         " warning_high DECIMAL(12,4) NULL,",
         " module_type VARCHAR(32) NULL,",
         " effective_from DATE NULL,",
         " effective_to DATE NULL",
         ")"));
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- 4) report_archive: 원본에 있으면 LIKE, 없으면 더미용 스키마 생성
SET @exists_ra=(SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES
                WHERE TABLE_SCHEMA=@src_schema AND TABLE_NAME='report_archive' AND TABLE_TYPE='BASE TABLE');
SET @sql=IF(@exists_ra=1,
  CONCAT('CREATE TABLE IF NOT EXISTS `',@dst_schema,'`.report_archive LIKE `',@src_schema,'`.report_archive'),
  CONCAT('CREATE TABLE IF NOT EXISTS `',@dst_schema,"`.report_archive (",
         " id BIGINT AUTO_INCREMENT PRIMARY KEY,",
         " period ENUM('D','W','M') NOT NULL,",
         " report_date DATE NOT NULL,",
         " audience VARCHAR(32) NOT NULL DEFAULT 'LINE',",
         " title VARCHAR(255) NULL,",
         " summary_json JSON NULL,",
         " html MEDIUMTEXT NOT NULL,",
         " created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,",
         " UNIQUE KEY uq_period_date_audience (period, report_date, audience)",
         ")"));
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- 5) 기준 데이터 복사(원본에 있을 때만)
-- defect_code
SET @exists=(SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES
             WHERE TABLE_SCHEMA=@src_schema AND TABLE_NAME='defect_code' AND TABLE_TYPE='BASE TABLE');
SET @sql=IF(@exists=1,
  CONCAT('INSERT IGNORE INTO `',@dst_schema,'`.defect_code SELECT * FROM `',@src_schema,'`.defect_code'),
  'SET @noop:=1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- spec_limit
SET @exists=(SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES
             WHERE TABLE_SCHEMA=@src_schema AND TABLE_NAME='spec_limit' AND TABLE_TYPE='BASE TABLE');
SET @sql=IF(@exists=1,
  CONCAT('INSERT IGNORE INTO `',@dst_schema,'`.spec_limit SELECT * FROM `',@src_schema,'`.spec_limit'),
  'SET @noop:=1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- kpi_target
SET @exists=(SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES
             WHERE TABLE_SCHEMA=@src_schema AND TABLE_NAME='kpi_target' AND TABLE_TYPE='BASE TABLE');
SET @sql=IF(@exists=1,
  CONCAT('INSERT IGNORE INTO `',@dst_schema,'`.kpi_target SELECT * FROM `',@src_schema,'`.kpi_target'),
  'SET @noop:=1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- 6) 더미 DB용 활성 규격 뷰
USE `secondary_battery_dummy_db`;
CREATE OR REPLACE VIEW `vw_spec_active` AS
SELECT s.*
FROM spec_limit s
JOIN (
  SELECT module_type, metric, MAX(effective_from) AS eff
  FROM spec_limit
  WHERE effective_from <= CURRENT_DATE()
    AND (effective_to IS NULL OR effective_to >= CURRENT_DATE())
  GROUP BY module_type, metric
) x ON x.module_type=s.module_type AND x.metric=s.metric AND x.eff=s.effective_from
WHERE (s.effective_to IS NULL OR s.effective_to >= CURRENT_DATE());